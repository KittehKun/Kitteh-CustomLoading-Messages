export interface IEmptyRequestData {
}
