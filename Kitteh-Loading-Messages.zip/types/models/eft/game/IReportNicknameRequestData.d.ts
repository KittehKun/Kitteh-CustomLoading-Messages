export interface IReportNicknameRequestData {
    uid: string;
}
