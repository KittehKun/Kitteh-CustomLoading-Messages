export interface IGetMiniProfileRequestData {
    username: string;
    password: string;
}
