export interface IValidateNicknameRequestData {
    nickname: string;
}
