export interface IGetMarketPriceRequestData {
    templateId: string;
}
