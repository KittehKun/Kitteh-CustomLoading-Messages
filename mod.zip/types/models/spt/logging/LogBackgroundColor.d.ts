export declare enum LogBackgroundColor {
    default = "",
    black = "blackBG",
    red = "redBG",
    green = "greenBG",
    yellow = "yellowBG",
    blue = "blueBG",
    magenta = "magentaBG",
    cyan = "cyanBG",
    white = "whiteBG"
}
