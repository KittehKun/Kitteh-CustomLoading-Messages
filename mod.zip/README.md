# Mod Description
This is a mod designed for the SPT-AKI project where profile loading messages are customized!

# Installation Instructions
1. Navigate to the mod's releases: https://github.com/KittehKun/Kitteh-CustomLoading-Messages/releases
2. Download Kitteh-Loading-Messages.zip
3. Unzip the archive to your SPT-AKI mods folder located at {Your SPT-AKI Installation}/user/mods
4. Enjoy!