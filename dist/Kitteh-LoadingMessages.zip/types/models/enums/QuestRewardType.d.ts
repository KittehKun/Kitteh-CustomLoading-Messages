export declare enum QuestRewardType {
    Skill = "Skill",
    Experience = "Experience",
    TraderStanding = "TraderStanding",
    TraderUnlock = "TraderUnlock",
    Item = "Item",
    AssortmentUnlock = "AssortmentUnlock"
}
