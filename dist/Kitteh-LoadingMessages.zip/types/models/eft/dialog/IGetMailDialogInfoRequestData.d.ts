export interface IGetMailDialogInfoRequestData {
    dialogId: string;
}
