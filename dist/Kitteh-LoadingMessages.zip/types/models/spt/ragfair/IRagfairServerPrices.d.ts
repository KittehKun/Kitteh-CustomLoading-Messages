export interface IRagfairServerPrices {
    static: Record<string, number>;
    dynamic: Record<string, number>;
}
